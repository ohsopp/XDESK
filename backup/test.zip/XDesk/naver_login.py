from PySide6.QtCore import QUrl, Signal, Slot, QObject
from PySide6.QtWebEngineWidgets import QWebEngineView

class NaverLogin(QObject):
    naverLoginSuccess = Signal()

    def __init__(self):
        super().__init__()
        self.webView = QWebEngineView()
        self.webView.setWindowTitle('Naver Login')
        self.webView.resize(800, 600)
        self.webView.urlChanged.connect(self.onUrlChanged)

    @Slot()
    def openNaverLoginWindow(self):
        login_url = 'https://i11a102.p.ssafy.io/oauth/naver/login/'
        self.webView.setUrl(QUrl(login_url))
        self.webView.show()

    def onUrlChanged(self, url):
        if 'oauth_token' in url.toString():  #url에 oauth_token 단어가 들어가 있다면 창 종료
            self.naverLoginSuccess.emit()
            self.webView.close()
