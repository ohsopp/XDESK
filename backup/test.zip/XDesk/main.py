# This Python file uses the following encoding: utf-8
import sys
from pathlib import Path

from PySide6.QtCore import QUrl
from PySide6.QtWidgets import QApplication
from PySide6.QtQml import QQmlApplicationEngine
#from naver_login import NaverLogin
from pyinterface import PyInterface
from PySide6.QtGui import QFontDatabase

if __name__ == "__main__":
    app = QApplication(sys.argv)
    engine = QQmlApplicationEngine()
    qml_file = Path(__file__).resolve().parent / "main.qml"

    #폰트
    fontDB = QFontDatabase()
    fontDB.addApplicationFont("/home/pi/test/XDesk/font/Pretendard-Black.otf")
    fontDB.addApplicationFont("/home/pi/test/XDesk/font/Pretendard-Bold.otf")
    fontDB.addApplicationFont("/home/pi/test/XDesk/font/Pretendard-ExtraBold.otf")
    fontDB.addApplicationFont("/home/pi/test/XDesk/font/PretendardVariable.ttf")

    '''naverLogin = NaverLogin()
    context = engine.rootContext()
    context.setContextProperty("naverLogin", naverLogin)

    def handleLoginSuccess():
        root_object = engine.rootObjects()[0]
        root_object.goToNextPage()

    naverLogin.naverLoginSuccess.connect(handleLoginSuccess)
    '''

    pyinterface = PyInterface()
    engine.rootContext().setContextProperty("pyinterface", pyinterface)

    engine.load(qml_file)
    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec())
