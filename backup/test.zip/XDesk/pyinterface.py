import subprocess
import sys
from PySide6.QtCore import QObject, Slot, Signal

class PyInterface(QObject):
    scriptFinished = Signal()

    @Slot()
    def runScript(self):
        # 원격 서버에서 파이썬 스크립트 실행
        remote_command = ["ssh", "orin@192.168.137.196", "python3 /home/orin/test/new_total.py"]
        
        # 로컬에서 파이썬 스크립트 실행
        local_command = ["python3", "/home/pi/test/total_test.py"]
        
        try:
            # 두 개의 명령어를 동시에 실행
            #process1 = subprocess.Popen(remote_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            process2 = subprocess.Popen(local_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            # 각 프로세스의 출력과 오류를 확인
            #stdout1, stderr1 = process1.communicate()
            stdout2, stderr2 = process2.communicate()
            
            self.scriptFinished.emit()

            '''
            # 결과 확인 및 오류 처리
            if process1.returncode != 0:
                print("Remote command failed with error:", stderr1)
                sys.exit(process1.returncode)
            
            if process2.returncode != 0:
                print("Local command failed with error:", stderr2)
                sys.exit(process2.returncode)
            
            # 각 프로세스의 결과 출력 (디버깅 용도)
            print("Remote command output:", stdout1)
            print("Local command output:", stdout2)
            '''

        except Exception as e:
            print("An error occurred:", e)
            sys.exit(1)
