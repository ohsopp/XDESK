from gpiozero import AngularServo, DistanceSensor
from time import sleep
import socket

# 서보 모터 설정
servo = AngularServo(16, min_angle=0, max_angle=90)
servo_reset = 60
servo_left = 30
servo_right = 90
servo.angle = servo_reset

# 초음파 센서 설정
sensor = DistanceSensor(echo=15, trigger=14)

# 클라이언트 설정
HOST = '192.168.137.196' # 서버의 IP 주소
PORT = 13246 # 서버와 동일한 포트 번호

def set_servo_motor(direction):
    global servo_reset
    if direction == "left":
        servo.angle = servo_left
    elif direction == "right":
        servo.angle = servo_right

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    data = s.recv(1024)
    data = data.decode()
    if data == 'Welcome!':
        print(data)
        while True:
            message = str(sensor.distance)
            s.sendall(message.encode())
            if message.lower() == 'quit':
                print("Closing connection.")
                break
            data = s.recv(1024)
            data = data.decode()
            print(f"Received from server: {data}")
            if data.lower() == 'up':
                set_servo_motor("left")
            elif data.lower() == 'down':
                set_servo_motor("right")
            else:
                servo.angle = servo_reset
                #break
    else:
        print(f"Rejected connection from server.")

servo.close()
