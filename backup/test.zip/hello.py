import subprocess

command = ["ssh", "orin@192.168.137.196", "python3 /home/orin/test/hi.py"]
result = subprocess.run(command, capture_output=True, text=True)

print(result.stdout)

