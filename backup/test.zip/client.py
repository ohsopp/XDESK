'''import socket

# 클라이언트 설정
HOST = '192.168.137.196' # 서버의 IP 주소
PORT = 13246 # 서버와 동일한 포트 번호 

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
	s.connect((HOST, PORT))
	while True:
		message = input("Enter message to server: ")
		s.sendall(message.encode())
		if message.lower() == 'quit':
			print("Closing connection.")
			break
		data = s.recv(1024)
		print(f"Received from server: {data.decode()}")
'''
import socket

# 클라이언트 설정
HOST = '192.168.137.196' # 서버의 IP 주소
PORT = 13246 # 서버와 동일한 포트 번호 

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
	s.connect((HOST, PORT))
	data = s.recv(1024)
	data = data.decode()
	if data == 'Welcome!':
		while True:
			message = input("Enter message to server: ")
			s.sendall(message.encode())
			if message.lower() == 'quit':
				print("Closing connection.")
				break
			data = s.recv(1024)
			print(f"Received from server: {data.decode()}")
	else:
		print(f"Rejected connection from server.")
