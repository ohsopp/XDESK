from gpiozero import AngularServo
from time import sleep

servo = AngularServo(16, min_angle=0, max_angle=90)
servo.angle = 55
sleep(0.5)

while True:
    angle = int(input("Angle : "))
    servo.angle = angle
    #sleep(0.5)
    '''for i in range(0, 91, 30):
        servo.angle = i
        print(i)
        sleep(3)
    '''
