from gpiozero import AngularServo, Motor, PWMOutputDevice
from time import sleep

servo = AngularServo(16, min_angle=0, max_angle=90)
servo.angle = 55

# GPIO 핀 설정
enA = PWMOutputDevice(18)
in1 = 23
in2 = 24

# Motor A 설정
motorA = Motor(forward=in1, backward=in2)
mode = 0

while True:
    mode = int(input("Mode : "))
    if mode == 1:
        motorA.backward()
        enA.value = 1
    elif mode == 2:
        servo.angle = 75
        sleep(0.5)
        motorA.stop()
    elif mode == 3:
        servo.angle = 55
        sleep(0.5)
        motorA.stop()
        break
