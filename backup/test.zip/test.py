from gpiozero import Motor, PWMOutputDevice, DistanceSensor
from time import sleep
import socket

# GPIO 핀 설정
enA = PWMOutputDevice(18)
in1 = 23
in2 = 24

# Motor A 설정
motorA = Motor(forward=in1, backward=in2)
is_moving  = False

# 초음파 센서 설정
sensor = DistanceSensor(echo=15, trigger=14)

# 클라이언트 설정
HOST = '192.168.137.196' # 서버의 IP 주소
PORT = 13246 # 서버와 동일한 포트 번호

def set_motor_speed(motor, pwm_pin, speed, direction):
    if direction == "forward":
        motor.forward()
    elif direction == "backward":
        motor.backward()
    pwm_pin.value = speed / 100.0

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    data = s.recv(1024)
    data = data.decode()
    if data == 'Welcome!':
        print(data)
        while True:
            message = str(sensor.distance)
            #print(message)
            s.sendall(message.encode())
            if message.lower() == 'quit':
                print("Closing connection.")
                break
            data = s.recv(1024)
            data = data.decode()
            print(f"Received from server: {data}")
            if data.lower() == 'up':
                set_motor_speed(motorA, enA, 100, "forward")
            elif data.lower() == 'down':
                set_motor_speed(motorA, enA, 100, "backward")
            else:
                motorA.stop()
                #break
    else:
        print(f"Rejected connection from server.")

motorA.stop()
