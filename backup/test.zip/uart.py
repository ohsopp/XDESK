import serial
from time import sleep

ser = serial.Serial('/dev/serial0', 115200)

def send_data(data):
    ser.write(data.encode())
    print(f"Sent: {data}")

try:
    send_data("Hello from Raspberry Pi!")
    while True:
        sleep(1)

except KeyboardInterrupt:
    ser.close()

