from gpiozero import AngularServo, Motor, PWMOutputDevice, DistanceSensor
import socket
import time

# 리니어 액추에이터 설정
enA = PWMOutputDevice(18)
in1 = 23
in2 = 24
motorA = Motor(forward=in1, backward=in2)

# 서보 모터 설정
servo = AngularServo(16, min_angle=0, max_angle=90)
servo_reset = 55
servo_left = 45
servo_right = 75
servo.angle = servo_right
time.sleep(0.5)
servo.angle = servo_reset
time.sleep(0.5)

# 초음파 센서 설정
sensor = DistanceSensor(echo=15, trigger=14)

# 클라이언트 설정
HOST = '192.168.137.196' # 서버의 IP 주소
PORT = 13246 # 서버와 동일한 포트 번호

modes = ['ready', 'servo', 'linear', 'stop']
mode_num = 0

def servo_motor(data):
    global servo
    if data.lower() == 'up':
        servo.angle = servo_left
        time.sleep(0.1)
    elif data.lower() == 'down':
        servo.angle = servo_right
        time.sleep(0.1)
    else:
        servo.angle = servo_reset

def linear_motor(data, speed):
    global enA
    if data.lower() == 'up':
        motorA.forward()
    elif data.lower() == 'down':
        motorA.backward()
    enA.value = speed / 100.0

def socket_client():
    global mode_num, servo

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        data = s.recv(1024)
        data = data.decode()
        if data == 'Welcome!':
            print(data)
            mode_num = 1
            while True:
                data = s.recv(1024)
                if not data:
                    continue
                
                data = data.decode()
                print(f"Received from server: {data}")

                if data == 'switch':
                    mode_num = 2
                    servo.angle = servo_reset
                    time.sleep(0.5)
                    servo.close()
                    #message = str(sensor.distance)
                    #s.sendall(message.encode())
                elif data == 'stop':
                    mode_num = 3
                    
                    servo.angle = servo_reset
                    time.sleep(0.5)
                    servo.close()

                    #linear_motor('down', 100)
                    #time.sleep(10)
                    motorA.close()
                    #message = str(sensor.distance)
                    #s.sendall(message.encode())

                if modes[mode_num] == modes[1]:
                    servo_motor(data)
                elif modes[mode_num] == modes[2]:
                    linear_motor(data, 100)
                elif modes[mode_num] == modes[3]:
                    break

        else:
            print(f"Rejected connection from server.")

if __name__ == '__main__':
    socket_client()

