from gpiozero import LED, MCP3008
from signal import pause

# MCP3008 ADC 사용하여 CDS 센서 값을 읽어옵니다.
# MCP3008 채널 0에 CDS 센서가 연결되어 있다고 가정합니다.
cds = MCP3008(channel=0)
led = LED(25)

# CDS 센서의 값에 따라 LED를 켜고 끕니다.
def check_light():
    # CDS 센서 값이 일정 수준(예: 0.5) 이하일 때 LED 켜기
    if cds.value < 0.5:
        led.on()
    else:
        led.off()

# 주기적으로 check_light 함수를 호출합니다.
from time import sleep

while True:
    #check_light()
    print(cds.value)
    sleep(1)  # 1초 간격으로 체크

# 프로그램이 종료되지 않도록 대기합니다.
pause()

